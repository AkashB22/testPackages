let mongoose = require('mongoose');
let schema = mongoose.schema;

module.exports = mongoose.model(dynamicSchema);